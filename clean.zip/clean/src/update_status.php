<?php
session_start();
require_once __DIR__ . '/helpers.php';

if (!isset($_SESSION['user']['id']) || empty($_POST['app_id']) || empty($_POST['status'])) {
    header("Location: /clean/login.html");
    exit;
}

$connect = getDB();
$appId = (int)$_POST['app_id'];
$status = $_POST['status'];

// Обновление статуса заявки
$updateQuery = $connect->prepare("UPDATE request SET status = ? WHERE id = ?");
$updateQuery->bind_param("si", $status, $appId);
if ($updateQuery->execute()) {
    header("Location: /clean/admin_panel.php");
    exit;
} else {
    echo "Ошибка обновления статуса.";
}
