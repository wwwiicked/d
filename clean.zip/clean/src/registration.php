<?php

require_once __DIR__ . '/helpers.php';


// Получение данных из формы
$login = $_POST['login'];
$password = $_POST['password'];
$surname = $_POST['surname'];
$name = $_POST['name'];
$patronymic = $_POST['patronymic'];
$phone = $_POST['phone'];
$email = $_POST['email'];

// Подключение к базе данных
$connect = getDB();

// Подготовленный запрос для предотвращения SQL-инъекций
$sql = "INSERT INTO `users` (login, password, surname, name, patronymic, phone, email) VALUES ('$login', '$password', '$surname', '$name', '$patronymic', '$phone', '$email')";
if ($connect -> query($sql) === TRUE) {
    header("Location: http://localhost/clean/login.html");
    // echo 'Регистрация прошла успешно!';
} else {
    echo 'Данный пользователь уже зарегистрирован :(';
}

?>
