<?php
session_start();
require_once __DIR__ . '/src/helpers.php'; // Подключение файла с функциями подключения к БД

$connect = getDB(); // Подключение к базе данных
$userId = $_SESSION['user']['id'];

// Получение данных текущего пользователя
$userQuery = $connect->prepare("SELECT `name`, `surname` FROM `users` WHERE `id` = ?");
$userQuery->bind_param("i", $userId);
$userQuery->execute();
$userResult = $userQuery->get_result();

if ($userResult && $userResult->num_rows > 0) {
    $userData = $userResult->fetch_assoc();
    $userName = $userData['name'] . ' ' . $userData['surname'];
} else {
    $userName = "Неизвестный пользователь";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $street = mysqli_real_escape_string($connect, $_POST['street']);
    $house = mysqli_real_escape_string($connect, $_POST['house']);
    $entrance = mysqli_real_escape_string($connect, $_POST['entrance']);
    $apartment = mysqli_real_escape_string($connect, $_POST['apartment']);
    $phone = mysqli_real_escape_string($connect, $_POST['phone']);
    $serviceType = isset($_POST['service_type']) ? mysqli_real_escape_string($connect, $_POST['service_type']) : null;
    $serviceDescription = isset($_POST['service_description']) ? mysqli_real_escape_string($connect, $_POST['service_description']) : null;
    $paymentType = mysqli_real_escape_string($connect, $_POST['payment_type']);

    // Выбор передаваемого значения (либо список, либо текст)
    $service = $serviceDescription && !empty(trim($serviceDescription)) ? $serviceDescription : $serviceType;

    // Записываем данные в базу данных
    $sqlInsertRequest = "
        INSERT INTO `request` 
        (`login_id`, `street`, `house`, `entrance`, `apartment`, `phone`, `service`, `payment`, `status`, `app_date`)
        VALUES 
        ('$userId', '$street', '$house', '$entrance', '$apartment', '$phone', '$service', '$paymentType', 'Ожидает', NOW())
    ";

    if (mysqli_query($connect, $sqlInsertRequest)) {
        echo "<script>alert('Заявка успешно создана.');</script>";
    } else {
        echo "<script>alert('Ошибка при создании заявки: " . mysqli_error($connect) . "');</script>";
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создать заявку</title>
    <link rel="stylesheet" href="assets/style2.css">
</head>
<body>
    <div class="container" style="height: auto;">
        <!-- Левое меню -->
        <aside class="sidebar">
            <div class="logo">
                <img src="assets/img/logo.png" alt="Логотип">
                <h1>Мой Не Сам</h1>
            </div>
            <nav>
                <div class="menu-buttons">
                    <a href="profile.php" class="button">История заявок</a>
                    <a href="#" class="button active">Создать заявку</a>
                </div>
            </nav>
            <a href="src/logout.php" class="logout">&larr; Выйти</a>
        </aside>

        <!-- Основной контент -->
        <main class="main-content">
            <header class="main-header">
                <h2>Создать заявку</h2>
                <div class="user">
                    <span><?= htmlspecialchars($userName) ?></span>
                    <div class="user-avatar"></div>
                </div>
            </header>
            <section class="request-form">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="street">Улица <span class="required">*</span></label>
                        <input type="text" id="street" name="street" placeholder="Укажите улицу" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="house">Дом (корпус)</label>
                            <input type="text" id="house" name="house" placeholder="Дом (корпус)">
                        </div>
                        <div class="form-group">
                            <label for="entrance">Подъезд</label>
                            <input type="text" id="entrance" name="entrance" placeholder="Подъезд">
                        </div>
                        <div class="form-group">
                            <label for="apartment">Квартира/помещение</label>
                            <input type="text" id="apartment" name="apartment" placeholder="Квартира/помещение">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="phone">Номер телефона <span class="required">*</span></label>
                        <input type="tel" id="phone" name="phone" placeholder="Введите номер телефона" required>
                    </div>
                    <div class="form-group">
                        <label for="service_type">Вид услуги <span class="required">*</span></label>
                        <select id="service_type" name="service_type" required>
                            <option value="">Выберите вид услуги</option>
                            <option value="Уборка квартиры/дома">Уборка квартиры/дома</option>
                            <option value="Уборка офиса">Уборка офиса</option>
                            <option value="Мытье окон/фасадов">Мытье окон/фасадов</option>
                            <option value="Дезинфекция">Дезинфекция</option>
                            <option value="Химчистка">Химчистка</option>
                            <option value="Удаление сложных загрязнений">Удаление сложных загрязнений</option>
                        </select>
                        <label>
                            <input type="checkbox" id="other_service" name="other_service"> Другая услуга
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="service_description">Услуга <span class="required">*</span></label>
                        <textarea id="service_description" name="service_description" placeholder="Введите описание услуги" disabled></textarea>
                    </div>
                    <div class="form-group">
                        <label>Тип оплаты <span class="required">*</span></label>
                        <div class="payment-options">
                            <label>
                                <input type="radio" name="payment_type" value="Наличные" required> Наличные
                            </label>
                            <label>
                                <input type="radio" name="payment_type" value="Карта"> Банковская карта
                            </label>
                        </div>
                    </div>
                    <button type="submit" class="submit-button">Отправить заявку</button>
                </form>
            </section>
        </main>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>
