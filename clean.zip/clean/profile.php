<?php
session_start();
require_once __DIR__ . '/src/helpers.php';

// Проверка авторизации пользователя
if (!isset($_SESSION['user']['id'])) {
    header("Location: http://localhost/clean/login.html");
    exit;
}

$connect = getDB();
$userId = $_SESSION['user']['id'];

// Получение данных текущего пользователя
$userQuery = $connect->prepare("SELECT `name`, `surname` FROM `users` WHERE `id` = ?");
$userQuery->bind_param("i", $userId);
$userQuery->execute();
$userResult = $userQuery->get_result();

if ($userResult && $userResult->num_rows > 0) {
    $userData = $userResult->fetch_assoc();
    $userName = $userData['name'] . ' ' . $userData['surname'];
} else {
    $userName = "Неизвестный пользователь";
}

// Получение заявок текущего пользователя
$requestQuery = $connect->prepare("SELECT `service`, `app_date`, `status` FROM `request` WHERE `login_id` = ? ORDER BY `app_date` DESC");
$requestQuery->bind_param("i", $userId);
$requestQuery->execute();
$requestResult = $requestQuery->get_result();

$requests = [];
if ($requestResult && $requestResult->num_rows > 0) {
    while ($row = $requestResult->fetch_assoc()) {
        $requests[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>История заявок</title>
    <link rel="stylesheet" href="assets/style2.css">
</head>
<body>
    <div class="container">
        <!-- Левое меню -->
        <aside class="sidebar">
            <div class="logo">
                <img src="assets/img/logo.png" alt="Логотип">
                <h1>Мой Не Сам</h1>
            </div>
            <nav>
                <div class="menu-buttons">
                    <a href="#" class="button active">История заявок</a>
                    <a href="create_app.php" class="button">Создать заявку</a>
                </div>
            </nav>
            <a href="src/logout.php" class="logout"> Выйти</a>
        </aside>

        <!-- Основной контент -->
        <main class="main-content">
            <header class="main-header">
                <h2>История заявок</h2>
                <div class="user">
                    <span><?= htmlspecialchars($userName) ?></span>
                    <div class="user-avatar"></div>
                </div>
            </header>
            <section class="request-history">
                <?php if (empty($requests)): ?>
                    <p class="no-requests">Заявки отсутствуют</p>
                <?php else: ?>
                    <?php foreach ($requests as $request): ?>
                        <div class="request-row">
                            <div class="request-item"><?= htmlspecialchars($request['service']) ?></div>
                            <div class="request-date"><?= htmlspecialchars($request['app_date']) ?></div>
                            <div class="request-status <?= strtolower($request['status']) ?>">
                                <?= htmlspecialchars($request['status']) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>
        </main>
    </div>
</body>
</html>
