<?php
session_start();
require_once __DIR__ . '/src/helpers.php';

// Проверка авторизации пользователя
if (!isset($_SESSION['user']['id'])) {
    header("Location: /clean/login.html");
    exit;
}

$connect = getDB();

// SQL-запрос для получения заявок
$sql = "
    SELECT 
        u.name AS user_name,
        u.surname AS user_surname,
        u.login AS user_login,
        a.street,
        a.house,
        a.entrance,
        a.apartment,
        a.phone AS user_phone,
        a.service,
        a.payment,
        a.app_date,
        a.status,
        a.id AS app_id
    FROM 
        request a
    JOIN 
        users u ON a.login_id = u.id
    ORDER BY 
        a.app_date DESC
";

$stmt = $connect->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

$requests = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Заявки пользователей</title>
    <link rel="stylesheet" href="assets/style2.css">
</head>
<body>
<div class="container">
    <!-- Левое меню -->
    <aside class="sidebar">
        <div class="logo">
            <img src="assets/img/logo.png" alt="Логотип">
            <h1>Мой Не Сам</h1>
        </div>
        <nav>
            <div class="menu-buttons">
                <a href="#" class="button active">Заявки пользователей</a>
            </div>
        </nav>
        <a href="src/logout.php" class="logout"> Выйти</a>
    </aside>

    <!-- Основной контент -->
    <main class="main-content">
        <header class="main-header">
            <h2>Заявки пользователей</h2>
        </header>
        <section class="requestions">
            <table>
                <thead>
                <tr>
                    <th>Имя пользователя</th>
                    <th>Логин</th>
                    <th>Услуга</th>
                    <th>Номер телефона</th>
                    <th>Дата создания</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($requests)): ?>
                    <tr>
                        <td colspan="6">Заявки отсутствуют</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($requests as $request): ?>
                        <tr>
                            <td><?= htmlspecialchars($request['user_name'] . ' ' . $request['user_surname']) ?></td>
                            <td><?= htmlspecialchars($request['user_login']) ?></td>
                            <td><?= htmlspecialchars($request['service']) ?></td>
                            <td><?= htmlspecialchars($request['user_phone']) ?></td>
                            <td><?= htmlspecialchars($request['app_date']) ?></td>
                            <td>
                                <form method="POST" action="src/update_status.php">
                                    <input type="hidden" name="app_id" value="<?= htmlspecialchars($request['app_id']) ?>">
                                    <select name="status" class="status-select" onchange="this.form.submit()">
                                        <option value="Ожидает" <?= $request['status'] === 'Ожидает' ? 'selected' : '' ?>>В работе</option>
                                        <option value="Выполнено" <?= $request['status'] === 'Выполнено' ? 'selected' : '' ?>>Выполнено</option>
                                        <option value="Отменено" <?= $request['status'] === 'Отменено' ? 'selected' : '' ?>>Отменено</option>
                                    </select>
                                </form>
                            </td>
                            <td>
                                <button onclick="showDetails(<?= htmlspecialchars(json_encode($request)) ?>)">⋮</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </section>
    </main>
</div>

<!-- Модальное окно -->
<div class="modal" id="detailsModal">
    <div class="modal-close" onclick="closeModal()">×</div>
    <div class="modal-header">Подробности заявки</div>
    <div class="modal-content" id="modalContent"></div>
</div>

<script>
    function showDetails(request) {
        const modal = document.getElementById('detailsModal');
        const content = document.getElementById('modalContent');
        content.innerHTML = `
            <p><strong>Имя:</strong> ${request.user_name} ${request.user_surname}</p>
            <p><strong>Логин:</strong> ${request.user_login}</p>
            <p><strong>Адрес:</strong> ${request.street}, дом ${request.house}, подъезд ${request.entrance}, квартира ${request.apartment}</p>
            <p><strong>Телефон:</strong> ${request.user_phone}</p>
            <p><strong>Услуга:</strong> ${request.service}</p>
            <p><strong>Оплата:</strong> ${request.payment}</p>
            <p><strong>Дата создания:</strong> ${request.app_date}</p>
            <p><strong>Статус:</strong> ${request.status}</p>
        `;
        modal.style.display = 'block';
    }

    function closeModal() {
        const modal = document.getElementById('detailsModal');
        modal.style.display = 'none';
    }
</script>
</body>
</html>
